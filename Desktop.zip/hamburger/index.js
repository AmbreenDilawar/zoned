
const ham=document.getElementById('ham')
const cross=document.getElementById('crose')
const list = document.querySelector('nav ul')


ham.addEventListener('click',()=>
{
    // console.log('checked')
    list.style.left = '0'
})

cross.addEventListener('click',()=>
{
    // console.log('checked')
    list.style.left = '-1000px'
})